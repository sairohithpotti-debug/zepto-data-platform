# Module 3: Support Assistant Microservice (/support_assistant)

## Overview
An Agentic Retrieval-Augmented Generation (RAG) customer support microservice for Zepto policy inquiries built using LangGraph, ChromaDB, Sentence Transformers, and FastAPI.

## Folder Structure

support_assistant/
├── doc_01.txt ... doc_08.txt
├── chroma_db/
├── support_graph.py
├── app.py
└── README.md


## Architecture & Workflow
1. Ingestion & Embedding: 8 policy text files embedded using all-MiniLM-L6-v2 and stored in persistent ChromaDB.
2. Intent Classification: Classifies queries into policy categories (delivery, refund_cancellation, membership, general).
3. Context Retrieval: Similarity search fetches top relevant policy chunks.
4. Response Generation: Formulates a tailored answer utilizing retrieved context.
5. API Layer: FastAPI POST /query endpoint exposing workflow with Pydantic models.

## Running the API
bash
uvicorn support_assistant.app:app --reload

